<?php
/*Her iki tapsiriqda arrayin elementlerine çatıb, ekrana vermək l lazimdir



1-ci tapsiriq.
$users = [
"name" => "Ayan",
"hobbies" => [
"football", "domino"
],
];*/


/*
$users = [
    "name" => "Ayan",
    "hobbies" => [
        "football", "domino"
    ],
];

echo "Name: " . $users["name"] . "\n";

echo "Hobbies:\n";
for ($i = 0; $i < count($users["hobbies"]); $i++) {
    echo "- " . $users["hobbies"][$i] . "\n";
}
*/





/*
2-ci tapsiriq.
$blogs = [
[
'title' => 'How can i learn PHP',
'tags' => [
'php', 'learn', 'it', 'programming'
],
'creator' => [
'name' => 'Janna',
'surname' => 'Smith'
],
'views' => [
[
'user' => 'Tom',
'ip' => '192.168.1.1'
],
[
'user' => 'Bob',
'ip' => '192.168.1.2'
],
[
'user' => 'Jon',
'ip' => '192.168.1.3'
],
],
],
[
'title' => 'How can i learn JS',
'tags' => [
'js', 'learn', 'it', 'programming', 'frontend', 'backend'
],
'creator' => [
'name' => 'Huseyn',
'surname' => 'Kerimov'
],
'views' => [
[
'user' => 'Selim',
'ip' => '192.168.1.1'
],
[
'user' => 'Bob',
'ip' => '192.168.1.2'
],
[
'user' => 'Jon',
'ip' => '192.168.1.3'
],
[
'user' => 'Elesger',
'ip' => '192.168.1.4'
],
[
'user' => 'Elovset',
'ip' => '192.168.1.5'
],
],

],

];*/


$blogs = [
    [
        'title' => 'How can i learn PHP',
        'tags' => [
            'php', 'learn', 'it', 'programming'
        ],
        'creator' => [
            'name' => 'Janna',
            'surname' => 'Smith'
        ],
        'views' => [
            [
                'user' => 'Tom',
                'ip' => '192.168.1.1'
            ],
            [
                'user' => 'Bob',
                'ip' => '192.168.1.2'
            ],
            [
                'user' => 'Jon',
                'ip' => '192.168.1.3'
            ],
        ],
    ],
    [
        'title' => 'How can i learn JS',
        'tags' => [
            'js', 'learn', 'it', 'programming', 'frontend', 'backend'
        ],
        'creator' => [
            'name' => 'Huseyn',
            'surname' => 'Kerimov'
        ],
        'views' => [
            [
                'user' => 'Selim',
                'ip' => '192.168.1.1'
            ],
            [
                'user' => 'Bob',
                'ip' => '192.168.1.2'
            ],
            [
                'user' => 'Jon',
                'ip' => '192.168.1.3'
            ],
            [
                'user' => 'Elesger',
                'ip' => '192.168.1.4'
            ],
            [
                'user' => 'Elovset',
                'ip' => '192.168.1.5'
            ],
        ],
    ],
];

$blogCount = count($blogs);

for ($i = 0; $i < $blogCount; $i++) {
    
    echo "Title: " . $blogs[$i]['title'] . "\n";
    
    
    echo "Tags: ";
    $tagsCount = count($blogs[$i]['tags']);
    for ($j = 0; $j < $tagsCount; $j++) {
        echo $blogs[$i]['tags'][$j];
        if ($j < $tagsCount - 1) {
            echo ", ";
        }
    }
    echo "\n";
    
    
    echo "Creator: " . $blogs[$i]['creator']['name'] . " " . $blogs[$i]['creator']['surname'] . "\n";
    
    
    echo "Views:\n";
    $viewsCount = count($blogs[$i]['views']);
    for ($k = 0; $k < $viewsCount; $k++) {
        echo " - User: " . $blogs[$i]['views'][$k]['user'] . ", IP: " . $blogs[$i]['views'][$k]['ip'] . "\n";
    }
    echo "\n";
}



?>       

