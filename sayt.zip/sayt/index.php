<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];

    if (!empty($username) && !empty($email)) {
        $_SESSION['username'] = $username;
        $_SESSION['email'] = $email;
        header("Location: index.php");
        exit();
    }
}

if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="az">
<head>
    <meta charset="UTF-8">
    <title>Daxil ol</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            width: 300px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"], input[type="email"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .error {
            color: red;
            display: none;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            border: none;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }
        button:disabled {
            background-color: #green;
        }
        .logout {
            margin-top: 10px;
            background-color: #ff0000;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (!isset($_SESSION['username']) || !isset($_SESSION['email'])): ?>
            <form id="loginForm" method="post" action="">
                <h2>Daxil ol</h2>
                <label for="username">İstifadəçi adı</label>
                <input type="text" id="username" name="username" required>
                <span id="usernameError" class="error">Bu xana zəruridir</span><br>

                <label for="email">E-poçt ünvanı</label>
                <input type="email" id="email" name="email" required>
                <span id="emailError" class="error">Bu xana zəruridir</span><br>

                <button type="submit" id="loginButton" disabled>DAXIL OL</button>
            </form>
        <?php else: ?>
            <h2>Profil</h2>
            <p>İstifadəçi adı: <?php echo htmlspecialchars($_SESSION['username']); ?></p>
            <p>E-poçt ünvanı: <?php echo htmlspecialchars($_SESSION['email']); ?></p>
            <form method="post" action="">
                <button type="submit" name="logout" class="logout">Çıxış</button>
            </form>
        <?php endif; ?>
    </div>

    <script>
        const username = document.getElementById('username');
        const email = document.getElementById('email');
        const loginButton = document.getElementById('loginButton');
        const usernameError = document.getElementById('usernameError');
        const emailError = document.getElementById('emailError');

        function validateForm() {
            let valid = true;

            if (username && username.value === '') {
                usernameError.style.display = 'block';
                valid = false;
            } else {
                usernameError.style.display = 'none';
            }

            if (email && email.value === '') {
                emailError.style.display = 'block';
                valid = false;
            } else {
                emailError.style.display = 'none';
            }

            loginButton.disabled = !valid;
            return valid;
        }

        if (username) username.addEventListener('input', validateForm);
        if (email) email.addEventListener('input', validateForm);

        if (document.getElementById('loginForm')) {
            document.getElementById('loginForm').addEventListener('submit', function(event) {
                if (!validateForm()) {
                    event.preventDefault();
                }
            });
        }
    </script>
</body>
</html>