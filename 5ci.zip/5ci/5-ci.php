<?php


//1..$fruits = ['apple', 'banana', 'cherry'];əgər arrayda "apple" varsa "orange" da əlavə olunsun,yoxdursa olmasin.



/*$meyveler = ['alma', 'banan', 'albalı'];

if (in_array('alma', $meyveler)) {
    $meyveler[] = 'portağal';
}

print_r($meyveler);*/


//2.$firstArray = [1, 2, 3];$secondArray = [4, 5, 6]; ikinci arraydaki elementleri birinciye 
//köçürün (2üsulla:həm hazir funksiya ile hem forla)


//1-ci usul
/*$firstArray = [1, 2, 3];
$secondArray = [4, 5, 6];

$mergedArray = array_merge($firstArray, $secondArray);

print_r($mergedArray);*/


//2-ci usul
/*$firstArray = [1, 2, 3];
$secondArray = [4, 5, 6];

for ($i = 0; $i < count($secondArray); $i++) {
    $firstArray[] = $secondArray[$i];
}

print_r($firstArray);*/



//3.$numbers = [1, 2, 3, 4, 5]; arrayin sonuncu elementini silin,ekrana həm yeni 
//vəziyyətdə olan arrayi çıxardın(yəni $numbers = [1, 2, 3, 4],həm də silinmiş 
//elementi(bu formada: "arraydan silinmiş element:5")

/*$reqemler = [1, 2, 3, 4, 5];
$silinmisElement = array_pop($reqemler);
print_r($reqemler);
echo "arraydan silinmiş element: " . $silinmisElement;*/



//4.$stack = ['a', 'b', 'c', 'd', 'e']; arrayin bütün elementlərini silin,boş arrayi print edin 
//ve her dövrdə silinen elementleri ekrana çıxarın ("arraydan silinmiş element:e";"arraydan silinmiş element:d  və s."


/*$stack = ['a', 'b', 'c', 'd', 'e'];

while (!empty($stack)) {
    $silinmisElement = array_pop($stack);
    echo "arraydan silinmiş element: " . $silinmisElement . "\n";
}


print_r($stack);*/


//5.arrayden son 3 element silinsin,(istenilen sayda elementi olan arraydan),$numbers = [1, 2, 3, 4, 5]


/*$reqemler = [1, 2, 3, 4, 5];
$silinecekSay = 3;


for ($i = 0; $i < $silinecekSay; $i++) {
    $silinmisElement = array_pop($reqemler);
    echo "arraydan silinmiş element: " . $silinmisElement . "\n";
}

print_r($reqemler);*/




//6.$person = [
//'name' => 'John',
    //'age' => 30,
    //'city' => 'New York',
//]; arrayda "age" keyi varsa "Johnun (x) yaşı var" ekrana çıxsın"(adı və yaşını manual özünüz əllə yazmayin,arrayin elementine çatılma qaydasi necədirsə o şəkildə)


/*$sexs = [
    'ad' => 'John',
    'yas' => 30,
    'seher' => 'New York',
];

if (array_key_exists('yas', $sexs)) {
    echo $sexs['ad'] . "un (" . $sexs['yas'] . ") yaşı var";
}*/



//7.$users = [
    //['id' => 1, 'name' => 'John', 'age' => 30],
    //['id' => 2, 'name' => 'Jane', 'age' => 25],
    //['id' => 3, 'name' => 'Doe', 'age' => 35],
//];
//butun userlerin ad ve yaslari cumle şəklində ekrana cixsin(johnun 30 yasi var ve s.)

/*$istifadeciler = [
    ['id' => 1, 'ad' => 'John', 'yas' => 30],
    ['id' => 2, 'ad' => 'Jane', 'yas' => 25],
    ['id' => 3, 'ad' => 'Doe', 'yas' => 35],
];

foreach ($istifadeciler as $istifadeci) {
    echo $istifadeci['ad'] . "un " . $istifadeci['yas'] . " yaşı var\n";
}*/


//8. $student = [
    //'name' => 'Alice',
    //'grades' => [
       // 'math' => 85,
       // 'science' => 90,
      //  'history' => 80,
   // ],
//];
//telebenin her fen uzre ballarini ekrana cixarin "riyaziyyat fenninden 85" ve s.


/*$telebe = [
    'ad' => 'Alice',
    'ballar' => [
        'riyaziyyat' => 85,
        'elmler' => 90,
        'tarix' => 80,
    ],
];

foreach ($telebe['ballar'] as $fenn => $bal) {
    echo $fenn . " fenninden " . $bal . "\n";
}*/



//9. hem array_map()-le hem de array walkla arrayin her elementinin üstüne 2 gelin, $array = [1, 2, 3, 4, 5];

//1-ci usul
/*
$array = [1, 2, 3, 4, 5];

$newArray = array_map(function($element) {
    return $element + 2;
}, $array);

print_r($newArray);*/


//2-ci usul
/*
$array = [1, 2, 3, 4, 5];

array_walk($array, function(&$element) {
    $element += 2;
});

print_r($array);*/



//10 array maple adlari Uppercase edin $names = ['alice', 'bob', 'charlie'];

/*$adlar = ['alice', 'bob', 'charlie'];

$yenıAdlar = array_map('strtoupper', $adlar);

print_r($yenıAdlar);*/


//11.array mapla iki arrayi cemleyin her elementini bir biri ile cemleyin $array1 = [1, 2, 3, 4, 5];
//$array2 = [10, 20, 30, 40, 50]; (netice bu olmalidir:Array
//(
// [0] => 11
// [1] => 22
// [2] => 33
  //  [3] => 44
  //  [4] => 55
//)


/*$array1 = [1, 2, 3, 4, 5];
$array2 = [10, 20, 30, 40, 50];

$mergedArray = array_map(function($a, $b) {
    return $a + $b;
}, $array1, $array2);

print_r($mergedArray);*/


//12 array walkla her adin sonuna Smith soyadini elave edin $names = ['Alice', 'Bob', 'Charlie'];(netice:Array
//(
    //[0] => Alice Smith
    //[1] => Bob Smith
    //[2] => Charlie Smith
//)

/*$adlar = ['Alice', 'Bob', 'Charlie'];

array_walk($adlar, function(&$ad, $key) {
    $ad .= ' Smith';
});

print_r($adlar);*/



//13$person = [
    //'name' => 'John',
    //'age' => 30,
//];  array walkla ad ve yasi modifikasiya edin ve elementler bu sekilde deyissin,qarsilarina user_ yazilsin)(netice:Array
//(
 //   [name] => user_John
  //  [age] => user_30
//)


/*$person = [
    'name' => 'John',
    'age' => 30,
];

array_walk($person, function(&$value, $key) {
    $value = "user_" . $value;
});

print_r($person);*/





link: https://github.com/LeylaMahmudovaa/php.git

?>       

