<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['register'])) {
        $istifadeciAdi = $_POST['username'];
        $soyad = $_POST['surname'];
        $email = $_POST['email'];
        $parol = $_POST['password'];

        
        $_SESSION['email'] = $email;
        $_SESSION['password'] = $parol;

        
        $yuklemeQovlugu = 'uploads/';
        if (!is_dir($yuklemeQovlugu)) {
            mkdir($yuklemeQovlugu, 0777, true);
        }

        foreach ($_FILES['images']['tmp_name'] as $anahtar => $tmp_name) {
            $faylAdi = basename($_FILES['images']['name'][$anahtar]);
            $hedefFaylYolu = $yuklemeQovlugu . $faylAdi;

            if (move_uploaded_file($tmp_name, $hedefFaylYolu)) {
                echo "$faylAdi faylı yükləndi.<br>";
            } else {
                echo "$faylAdi faylı yüklənərkən səhv baş verdi.<br>";
            }
        }

        
        header("Location: index.php?action=login");
        exit();
    } elseif (isset($_POST['login'])) {
        $email = $_POST['email'];
        $parol = $_POST['password'];

        if ($email == $_SESSION['email'] && $parol == $_SESSION['password']) {
            // Xoş gəlmisiniz səhifəsinə yönləndirin
            header("Location: index.php?action=welcome");
            exit();
        } else {
            echo "Email və ya parol yanlışdır.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Document</title>
</head>
<body>
    <?php if (isset($_GET['action']) && $_GET['action'] == 'login'): ?>
        <h2>Giriş</h2>
        <form action="index.php" method="post">
            Email: <input type="email" name="email" required><br>
            Parol: <input type="password" name="password" required><br>
            <input type="submit" name="login" value="Giriş">
        </form>
    <?php elseif (isset($_GET['action']) && $_GET['action'] == 'welcome'): ?>
        <h2>Xoş gəlmisiniz <?php echo $_SESSION['email']; ?></h2>
    <?php else: ?>
        <h2>İstifadəçi Qeydiyyatı</h2>
        <form action="index.php" method="post" enctype="multipart/form-data">
            İstifadəçi Adı: <input type="text" name="username" required><br>
            Soyad: <input type="text" name="surname" required><br>
            Email: <input type="email" name="email" required><br>
            Parol: <input type="password" name="password" required><br>
            Şəkillər: <input type="file" name="images[]" multiple required><br><br>
            <input type="submit" name="register" value="Qeydiyyat">
        </form>
    <?php endif; ?>
</body>
</html>